import ConfettiEffect from "../ConfettiEffect";

export default function ConfettiEffectExample() {
  return <ConfettiEffect active={true} />;
}
