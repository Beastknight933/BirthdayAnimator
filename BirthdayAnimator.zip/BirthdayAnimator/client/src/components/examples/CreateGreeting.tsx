import CreateGreeting from "../../pages/CreateGreeting";

export default function CreateGreetingExample() {
  return <CreateGreeting />;
}
