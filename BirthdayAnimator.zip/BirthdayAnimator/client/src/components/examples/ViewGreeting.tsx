import ViewGreeting from "../../pages/ViewGreeting";

export default function ViewGreetingExample() {
  return <ViewGreeting greetingId="demo123" />;
}
